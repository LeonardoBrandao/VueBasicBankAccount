<template>
  <div id="app">
      <div class="container">
          <app-buscar-conta></app-buscar-conta>
          <hr>
          <app-inserir-conta :contas="contas"></app-inserir-conta>
          <hr>
          <app-contas :contas="contas"></app-contas>
      </div>
  </div>
</template>

<script>
import appInserirConta from './components/InserirConta.vue';
import appBuscarConta from './components/BuscarConta.vue';
import appContas from './components/Contas.vue';

export default {
    name: 'app',
    data() {
      return {
          contas: [
            { id: 1, saldo: 150},
            { id: 2, saldo: 10},
            { id: 3, saldo: 2150},
            { id: 4, saldo: 1530},
            { id: 5, saldo: 1504},
          ]
      }
    },
    components: {
        appInserirConta,
        appBuscarConta,
        appContas
    }
}
</script>

<style>
</style>
