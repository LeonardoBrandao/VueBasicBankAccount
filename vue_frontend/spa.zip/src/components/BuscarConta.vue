<template>
    <div class="row justify-content-center">
        <h2 class="text-center col-sm-12">Buscar Conta</h2>
        <div class="form-group col-sm-8">
            <label for="buscarConta">Buscar conta por id:</label>
            <input id="buscarConta" type="text" class="form-control">
        </div>
        <div class="w-100"></div>
        <button class="btn btn-primary">Buscar</button>
    </div>
</template>