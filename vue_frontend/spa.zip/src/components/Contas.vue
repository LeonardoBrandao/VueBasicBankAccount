<template>
    <div class="row justify-content-md-center">
        <table class="table">
            <thead class="thead-light">
            <tr>
                <th scope="col">Numero</th>
                <th scope="col">Saldo</th>
                <th scope="col">Remover</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="conta in contas">
                <th scope="row">{{ conta.id }}</th>
                <td>{{ conta.saldo }}</td>
            </tr>
            </tbody>
        </table>
    </div>
</template>
<script>
    export default {
        props: ['contas']
    }
</script>
<style scoped>

</style>