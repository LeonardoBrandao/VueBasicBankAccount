<template>
    <div class="row justify-content-md-center">
        <h2 class="text-center col-sm-12">Inserir Conta</h2>
        <form class="col-sm-12 col-md-8">
            <div class="form-group">
                <label>Numero da conta:</label>
                <input id="numeroConta" name="nro_conta" type="text" class="form-control" v-model="numero" />
            </div>
            <div class="form-group">
                <label>Saldo:</label>
                <input type="text" id="saldo" name="saldo" required class="form-control" v-model="saldo">
            </div>
            <button id="btnSave" class="btn btn-success" @click="attConta">Atualizar</button>
            <button id="btnInsert" class="btn btn-primary" @click.prevent="insereConta">Inserir</button>
        </form>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                numero: null,
                saldo: null
            }
        },
        props: ['contas'],
        methods: {
            attConta() {
                return;
            },
            insereConta() {
                let conta = {
                    id: this.numero,
                    saldo: this.saldo
                };
                this.contas.push(conta);
                this.numero = '';
                this.saldo = '';
            }
        }
    }
</script>
<style scoped>

</style>